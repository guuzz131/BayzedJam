﻿using UnityEngine;
using System.Collections.Generic;

public class PreviewBlock : MonoBehaviour
{
    public List<Transform> sides = new List<Transform>();
}